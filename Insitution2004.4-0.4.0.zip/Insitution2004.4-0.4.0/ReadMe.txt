Institution 2004 0.4.0 by Aphex
http://www.iamaphex.net
aphex@iamaphex.net

To remove the server, run it with "server.exe /u".

Undetected copies on sale for $20, www.egold.com payments ONLY!!